import React, { useState } from 'react';
import axios from 'axios';
import Cookies from 'js-cookie';

function App({ postId }) {
  const [likeStatus, setLikeStatus] = useState(null);

  const handleLikeClick = () => {
    axios.post('http://localhost:8080/vote/client/1/like', null, { withCredentials: true })
      .then((response) => {
        setLikeStatus('좋아요 성공');
      })
      .catch((error) => {
        
        if (error) {
          console.log(error.response.data.message)
          // // 실패 응답에서 Set-Cookie 헤더가 있을 경우 수동으로 쿠키를 저장
          // const setCookieHeader = error.response.headers['set-cookie'];
          // if (setCookieHeader) {
          //   // 쿠키를 수동으로 저장
          //   setCookieHeader.forEach(cookie => {
          //     const [cookieName, cookieValue] = cookie.split('=');
          //     Cookies.set(cookieName, cookieValue, { path: '/', secure: true });
          //   });
          // }

          // setLikeStatus(error.response.data.message);
        } else {
          setLikeStatus('오류가 발생했습니다.');
        }
      });
  };

  return (
    <div>
      <button onClick={handleLikeClick}>좋아요</button>
      {likeStatus && <p>{likeStatus.message}</p>}
    </div>
  );
}

export default App;


// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import Cookies from 'js-cookie';
// import MainPage from './MainPage';
// import RegistrationPage from './RegistrationPage';

// function App() {
//   const [userRole, setUserRole] = useState(null);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
    
//     const token = Cookies.get('Authorization'); 

//     if (token) {
//       // 토큰이 있는 경우 서버에 사용자 정보 요청
//       axios.get('https://test.wabauniv.com:9998/vote/client/1/like', {
//         withCredentials: true,  // 쿠키를 포함한 요청을 허용
//           headers: {Authorization: `Bearer ${token}`,},
//         })
//         .then((response) => {
//           const { role } = response.data;
//           setUserRole(role);
//           setLoading(false);
//         })
//         .catch((error) => {
//           console.error('Failed to fetch user info:', error);
//           setLoading(false);
//         });
//     } else {
//       console.log("Error");
//     }
//   }, []);

//   if (loading) {
//     return <div>로딩 중...</div>;
//   }

//   if (userRole === 'ROLE_USER') {
//     return <MainPage />;
//   } else if (userRole === 'ROLE_GUEST') {
//     return <RegistrationPage />;
//   } else {
//     return <div>알 수 없는 권한입니다. 관리자에게 문의하세요.</div>;
//   }
// }

// export default App;