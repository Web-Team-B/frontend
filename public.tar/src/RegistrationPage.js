import React, { useState } from 'react';


function RegistrationPage() {
  return (
    <div>
      <h1>추가 회원가입 페이지</h1>
    </div>
  );
}

export default RegistrationPage;