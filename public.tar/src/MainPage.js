import React from 'react';

function MainPage() {
  return (
    <div>
      <h1>메인 페이지</h1>
    </div>
  );
}

export default MainPage;